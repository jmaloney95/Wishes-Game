
//{{BLOCK(scrollbar)

//======================================================================
//
//	scrollbar, 32x32@4, 
//	+ palette 16 entries, not compressed
//	+ 16 tiles not compressed
//	Total size: 32 + 512 = 544
//
//	Time-stamp: 2026-03-26, 19:57:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SCROLLBAR_H
#define GRIT_SCROLLBAR_H

#define scrollbarTilesLen 512
extern const unsigned char scrollbarTiles[512];

#define scrollbarPalLen 32
extern const unsigned short scrollbarPal[16];

#endif // GRIT_SCROLLBAR_H

//}}BLOCK(scrollbar)
