
//{{BLOCK(save)

//======================================================================
//
//	save, 32x64@4, 
//	+ palette 16 entries, not compressed
//	+ 32 tiles not compressed
//	Total size: 32 + 1024 = 1056
//
//	Time-stamp: 2026-03-26, 19:57:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SAVE_H
#define GRIT_SAVE_H

#define saveTilesLen 1024
extern const unsigned char saveTiles[1024];

#define savePalLen 32
extern const unsigned short savePal[16];

#endif // GRIT_SAVE_H

//}}BLOCK(save)
