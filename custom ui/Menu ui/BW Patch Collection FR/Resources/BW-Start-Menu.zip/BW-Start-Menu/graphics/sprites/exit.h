
//{{BLOCK(exit)

//======================================================================
//
//	exit, 16x32@4, 
//	+ palette 16 entries, not compressed
//	+ 8 tiles not compressed
//	Total size: 32 + 256 = 288
//
//	Time-stamp: 2026-03-26, 19:57:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_EXIT_H
#define GRIT_EXIT_H

#define exitTilesLen 256
extern const unsigned char exitTiles[256];

#define exitPalLen 32
extern const unsigned short exitPal[16];

#endif // GRIT_EXIT_H

//}}BLOCK(exit)
