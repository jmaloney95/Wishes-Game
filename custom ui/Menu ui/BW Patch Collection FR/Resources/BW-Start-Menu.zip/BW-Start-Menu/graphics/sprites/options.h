
//{{BLOCK(options)

//======================================================================
//
//	options, 32x64@4, 
//	+ palette 16 entries, not compressed
//	+ 32 tiles not compressed
//	Total size: 32 + 1024 = 1056
//
//	Time-stamp: 2026-03-26, 19:57:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_OPTIONS_H
#define GRIT_OPTIONS_H

#define optionsTilesLen 1024
extern const unsigned char optionsTiles[1024];

#define optionsPalLen 32
extern const unsigned short optionsPal[16];

#endif // GRIT_OPTIONS_H

//}}BLOCK(options)
