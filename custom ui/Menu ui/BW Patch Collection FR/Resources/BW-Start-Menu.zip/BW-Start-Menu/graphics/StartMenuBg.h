
//{{BLOCK(StartMenuBg)

//======================================================================
//
//	StartMenuBg, 256x160@4, 
//	+ palette 16 entries, not compressed
//	+ 41 tiles (t|f|p reduced) lz77 compressed
//	+ regular map (flat), lz77 compressed, 32x20 
//	Total size: 32 + 288 + 356 = 676
//
//	Time-stamp: 2026-03-26, 19:57:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTMENUBG_H
#define GRIT_STARTMENUBG_H

#define StartMenuBgTilesLen 288
extern const unsigned char StartMenuBgTiles[288];

#define StartMenuBgMapLen 356
extern const unsigned short StartMenuBgMap[178];

#define StartMenuBgPalLen 32
extern const unsigned char StartMenuBgPal[32];

#endif // GRIT_STARTMENUBG_H

//}}BLOCK(StartMenuBg)
