        .gba
        .thumb
        .open "BPRE0.gba","build/Option Menu.gba", 0x08000000

        .include "patches/pointer.s"

        .org 0x08800000
        .importobj "build/linked.o"
        .close
