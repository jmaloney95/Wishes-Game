build/src/option_menu.c.o: src/option_menu.c include/global.h \
 include/config.h include/gba/gba.h include/gba/defines.h \
 include/gba/io_reg.h include/gba/types.h include/gba/multiboot.h \
 include/gba/syscall.h include/gba/macro.h include/gba/isagbprint.h \
 include/constants/global.h include/constants/game_stat.h \
 include/global.fieldmap.h include/global.berry.h include/global.tv.h \
 include/pokemon.h include/constants/pokemon.h include/sprite.h \
 include/option_menu.h include/main.h include/menu.h include/task.h \
 include/text.h include/window.h include/scanline_effect.h \
 include/palette.h include/sprite.h include/task.h include/bg.h \
 include/gpu_regs.h include/window.h include/text.h include/text_window.h \
 include/international_string_util.h include/menu.h include/list_menu.h \
 include/string_util.h
include/global.h:
include/config.h:
include/gba/gba.h:
include/gba/defines.h:
include/gba/io_reg.h:
include/gba/types.h:
include/gba/multiboot.h:
include/gba/syscall.h:
include/gba/macro.h:
include/gba/isagbprint.h:
include/constants/global.h:
include/constants/game_stat.h:
include/global.fieldmap.h:
include/global.berry.h:
include/global.tv.h:
include/pokemon.h:
include/constants/pokemon.h:
include/sprite.h:
include/option_menu.h:
include/main.h:
include/menu.h:
include/task.h:
include/text.h:
include/window.h:
include/scanline_effect.h:
include/palette.h:
include/sprite.h:
include/task.h:
include/bg.h:
include/gpu_regs.h:
include/window.h:
include/text.h:
include/text_window.h:
include/international_string_util.h:
include/menu.h:
include/list_menu.h:
include/string_util.h:
